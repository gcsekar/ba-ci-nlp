export interface Window {
}
