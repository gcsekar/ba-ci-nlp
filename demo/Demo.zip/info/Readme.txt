Very first time:
1) Run Init.bat - You don't need to do this everytime

Giving the demo:
1) Login to https://lo-analytics-prep.bravosolution.com just before the demo. (This step is needed so the browser doesn't prompt you for password when opening the dashboard)
	username : cganesan
	password : jdOD83hds!
2) Run "run.bat". 
3) Wait for atleast 15 seconds for the demo to be up and running
4) Open google chrome and type the URL - "http://localhost:4200"
5) Initiate Virtual Assistant or IOT Demo as appropriate

Demo recommendations:
1) Always run the demo in Google Chrome if you want voice interactions
2) Some responses are very long. Voice assistant may take sometime to finish. 
  - Use voice interaction for questions that are tagged with "ASK" in talking points

Demo conclusion:
1) Run "stop.bat" - this will stop all the running demo instances and release back your machine resources

*** GOOD LUCK WITH THE DEMO ***